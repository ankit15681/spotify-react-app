import React from 'react';

const Header = () => {
  return <h1 className="main-heading">Spotify React App</h1>;
};

export default Header;
